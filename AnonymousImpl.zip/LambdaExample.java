package com.example.lambda;

public class LambdaExample {
	
	public static int sum(int[] numbers, Calculate c) {
		int total=0;
		for(int x:numbers) {
			if(c.test(x)) {
				total=total+x;
			}
		}
		return total;
	}
	
	
	
	public static void main(String[] args) {
		
			int[] numbers= {1,2,3,4,5,6,7,8,9,10};
			int result=0;
			
			//sum of numbers that are even
			//LambdaExample l=new LambdaExample();
			result=sum(numbers, new Calculate() {

				@Override
				public boolean test(int n) {
					// TODO Auto-generated method stub
					return n%2==0;
				}
				
			});
			
			
			System.out.println(result);
			// sum of numbers that are odd
			result=sum(numbers, new Calculate() {
				@Override
				public boolean test(int n) {
					// TODO Auto-generated method stub
					return n%2!=0;
				}
			});
			
			System.out.println(result);
			// sum of all numbers
			result=sum(numbers, new Calculate() {
				@Override
				public boolean test(int n) {
					// TODO Auto-generated method stub
					return true;
				}
			});
			System.out.println(result);
			// sum of numbers greater than 4
			result=sum(numbers, new Calculate() {

				@Override
				public boolean test(int n) {
					// TODO Auto-generated method stub
					return n>4;
				}
				
			});
			System.out.println(result);
		
	}

}
