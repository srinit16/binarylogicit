package com.example.lambda;

public class AllImpl implements Calculate {

	
	public boolean test(int n) {
		
		return true;
	}

	
	
}
