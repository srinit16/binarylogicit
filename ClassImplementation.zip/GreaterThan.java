package com.example.lambda;

public class GreaterThan implements Calculate {

	
	public boolean test(int n) {
		
		return (n>4);
	}

	
	
}
