package com.example.lambda;

@FunctionalInterface
public interface Calculate {
	
		boolean test(int n);
}
