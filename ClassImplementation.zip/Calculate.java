package com.example.lambda;

public interface Calculate {
	
		boolean test(int n);

}
