package com.example.lambda;

public class EvenImpl implements Calculate {

	
	public boolean test(int n) {
		
		return (n%2==0);
	}

	
	
}
